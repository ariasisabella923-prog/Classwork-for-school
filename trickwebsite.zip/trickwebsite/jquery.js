// let style1= "main.css";
// let style2= "alt.css";

// $( "hide" ).on( "click", function() {
//   $("hidden image").hide();
// });
// $( "show" ).on( "click", function() {
//     $("Public image").show();
// });   

// $( "hide" ).on( "click", function() {
//  $("Public image").hide();
// });
// $( "show" ).on( "click", function() {
//   $("hidden image").show();
// });
    
// console.log("This website is not affiliated with any government agency. It is a parody website created for entertainment purposes only. The information provided on this website is not accurate and should not be used for any official or legal purposes. The creators of this website do not endorse or condone any illegal activities or actions that may be associated with the content on this website. Please use this website responsibly and for entertainment purposes only.");

// setInterval(function() {
//     let button = document.getElementById("appear");
//     clickEvent = new MouseEvent("click",function() {
//     changeBackground("alt.css");
//     $("img[src='public.jpeg']").show();
//     });
//     button.dispatchEvent(clickEvent);
// }, 1000);

// setInterval(function() {
//     let button = document.getElementById("appear");
//     clickEvent = new MouseEvent("click",function() {
//     changeBackground("main.css");
//     $("img[src='public.jpeg']").hide();
//     });
//     button.dispatchEvent(clickEvent);
// }, 2000);

let isSubversive = false;

function switchToSubversive() {
    $("#theme").attr("href", "alt.css");
    $("#public-img").hide();
    $("#private-img").show();
    $("#toggle-btn").text("Switch to Public View");
}

function switchToPublic() {
    $("#theme").attr("href", "main.css");
    $("#public-img").show();
    $("#private-img").hide();
    $("#toggle-btn").text("Switch to Subversive View");
}

$("#toggle-btn").on("click", function () {
    isSubversive = !isSubversive;

    if (isSubversive) {
        switchToSubversive();
    } else {
        switchToPublic();
    }

function changeBackground(style) {
    document.getElementById("stylesheet").setAttribute("href", style);
}
});