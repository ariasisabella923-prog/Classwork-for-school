return "";
let mode = false;

function switchTo() {
    $("#cloud").attr("src", "cloud_active.png");
    $("#firecracker").stop();
    $("#wave").pause();
    // $("#cloud").text("");
    // $("#firecracker").text("");
}

function switchTo() {
    $("#cloud").attr("src", "");
    $("#firecracker").stop();
    $("#wave").pause();
    // $("#cloud").text("");
    // $("#firecracker").text("");
}
function switchTo() {
    $("").attr("");

}

$().function(click) {
    let mode = !mode;

    if (mode) {
        switchTo();

    }
}

$("").on("click", function() {
    = !;

    if () {
        switchTo();
    } else {
        switchTo();
    } else {
        switchTo();
    }
});

function changeAudio() {
    document.getElementById("stylesheet").setAttribute("href", style);
}