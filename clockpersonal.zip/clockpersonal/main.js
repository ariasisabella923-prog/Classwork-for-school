//  let fontSwitchBucket = -1;
// setInterval(function () {

//   let currentTime = new Date();

//   let hours   = currentTime.getHours();
//   let minutes = currentTime.getMinutes();
//   let seconds = currentTime.getSeconds();

   
// if (hours >= 18  || hours < 4) {
// let hours=currentTime.getHours();
//  if (hours < 10) {
//  hours= "0" + hours;
//  }

// let minutes=currentTime.getMinutes();
// if (minutes < 10) {
//  minutes= "0" + minutes;
//  }
//   let seconds=currentTime.getSeconds();
// if (seconds < 10) {
//     seconds= "0" + seconds;
//  }
// } 
// }
//  let bucket = Math.floor(minutes/ 10) % 2;

//   if (bucket !== fontSwitchBucket) {
//     fontSwitchBucket = bucket;

//     $("#clock").text("06" + ":" + "06" + ":" + "06");

//     setTimeout(function () {

//       if (bucket === 0) {
//         $("body").removeClass("font-LED").addClass("font-Glitch")
//       } else {
//         $("body").removeClass("font-Glitch").addClass("font-LED");
//       }

  

//   }
//   // if ($("#clock").text() === "00"+ ":" +"00" + ":" + "00"){
//  $("#clock").text(hours + ":" + minutes + ":" + seconds);
//   if (hours   < 10) hours   = "0" + hours;
//   if (minutes < 10) minutes = "0" + minutes;
//   if (seconds < 10) seconds = "0" + seconds;

//   $("#clock").text(hours + ":" + minutes + ":" + seconds);

//       fontSwitchBucket = bucket;
  
//       $("#clock").text(hours + ":" + minutes + ":" + seconds);

//   },1000);


//  let fontSwitchBucket = -1;
// setInterval(function () {

//   let currentTime = new Date();

//   let hours   = currentTime.getHours();
//   let minutes = currentTime.getMinutes();
//   let seconds = currentTime.getSeconds();

//   if (hours >= 18  || hours < 4) {
//     if (hours < 10) {
//       hours= "0" + hours;
//     }

//     if (minutes < 10) {
//       minutes= "0" + minutes;
//     }
//     if (seconds < 10) {
//       seconds= "0" + seconds;
//     }
//   } 

//   let bucket = Math.floor(seconds/ 10) % 5;

//   if (bucket !== fontSwitchBucket) {
//     fontSwitchBucket = bucket;

//     setTimeout(function () {

//       if (bucket === 0) {
//         $("body").removeClass("font-LED").addClass("font-Glitch")
//       } else {
//         $("body").removeClass("font-Glitch").addClass("font-LED");
//       }

//     }, 1000);
//   }

//   if (hours   < 10) hours   = "0" + hours;
//   if (minutes < 10) minutes = "0" + minutes;
//   if (seconds < 10) seconds = "0" + seconds;

//   $("#clock").text(hours + ":" + minutes + ":" + seconds);

// }, 1000); 

let fontSwitchBucket = -1;
 setInterval(function () {

let currentTime = new Date();

let hours = currentTime.getHours();
let minutes = currentTime.getMinutes();
let seconds = currentTime.getSeconds();

let displayHours = hours < 10 ? "0" + hours : String(hours);
let displayMinutes = minutes < 10 ? "0" + minutes : String(minutes);
let displaySeconds = seconds < 10 ? "0" + seconds : String(seconds);


if (hours >= 18 || hours < 4) {

  displayHours = hours < 10 ? "0" + hours : String(hours);
  displayMinutes = minutes < 10 ? "0" + minutes : String(minutes);
  displaySeconds = seconds < 10 ? "0" + seconds : String(seconds);

}

  setTimeout(function () {
let bucket = Math.floor(seconds / 15) % 2;

if (bucket !== fontSwitchBucket) {
  fontSwitchBucket = bucket;

  $("#clock").text(displayHours + ":" + displayMinutes + ":" + displaySeconds);

  setTimeout(function () {
    if (bucket === 0) {
      $("#clock").text("06" + ":" + "06" + ":" + "06").addClass("font-Glitch").removeClass("font-LED");
      
    } else {
      $("#clock").text("06" + ":" + "06" + ":" + "06").addClass("font-LED").removeClass("font-Glitch");
    }
  }, 0);
}
  }, 1000);

  $("#clock").text(displayHours + ":" + displayMinutes + ":" + displaySeconds);

}, 1000);

// let fontSwitchBucket = -1;

// setInterval(function () {
//   const currentTime = new Date();

//   const hours = currentTime.getHours();
//   const minutes = currentTime.getMinutes();
//   const seconds = currentTime.getSeconds();

//   const displayHours = hours < 10 ? "0" + hours : String(hours);
//   const displayMinutes = minutes < 10 ? "0" + minutes : String(minutes);
//   const displaySeconds = seconds < 10 ? "0" + seconds : String(seconds);

//   const realTime = displayHours + ":" + displayMinutes + ":" + displaySeconds;

//   setTimeout(function () {
//     const bucket = Math.floor(seconds / 5) % 2;

//     if (bucket !== fontSwitchBucket) {
//       fontSwitchBucket = bucket;

//       if (bucket === 0) {
//         $("#clock").text("06:06:06").addClass("font-Glitch")
//         $("#clock").removeClass("font-LED");

//         setTimeout(function () {
//           $("#clock").text(realTime);
//         }, 2000);

//       } else {
//         $("#clock").text(realTime);

//         setTimeout(function () {
//           $("#clock").removeClass("font-LED");
//           $("#clock").addClass("font-Glitch")
//         }, 0);
//       }

//     } else {
//       if (bucket !== 0 || fontSwitchBucket !== 0) {
//         $("#clock").text(realTime);
//       }
//     }

//   }, 1000);

//   $("#clock").text(realTime);

// }, 1000);

// let fontSwitchBucket = -1;

// setInterval(function () {
//   const currentTime = new Date();

//   const hours = currentTime.getHours();
//   const minutes = currentTime.getMinutes();
//   const seconds = currentTime.getSeconds();

//   const displayHours = hours < 10 ? "0" + hours : String(hours);
//   const displayMinutes = minutes < 10 ? "0" + minutes : String(minutes);
//   const displaySeconds = seconds < 10 ? "0" + seconds : String(seconds);

//   const realTime = displayHours + ":" + displayMinutes + ":" + displaySeconds;

//   setTimeout(function () {
//     const bucket = Math.floor(seconds / 5) % 2;

//     if (bucket !== fontSwitchBucket) {
//       fontSwitchBucket = bucket;

//       if (bucket === 0) {
        
//        removeClass("font-LED").addClass("font-Glitch");

//         setTimeout(function () {
//           $("#clock").text(realTime);
//         }, 2000);

//       } else {
//        $("#clock").text("06" + ":" + "06" + ":" + "06")
//         $("#clock").text(realTime).removeClass("font-Glitch").addClass("font-LED");
//       }

//     } else {
     
//       if (bucket !== 0 && fontSwitchBucket !== 0) {
//         $("#clock").text(realTime);
//       }
//     }

//   }, 1000);

//   $("#clock").text(realTime);

// }, 1000);