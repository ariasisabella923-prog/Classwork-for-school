"https://api.weather.gov/gridpoints/OKX/41,52/forecast";
// function getWeather(){

// // let decade +"" =



// }


function grabMyData (data) {
  //console.log(data.properties.periods[0].detailedForecast);
 
  
  let currentForecast = data.properties.periods[0].shortForecast;
  
  console.log(currentForecast)  
  
 $("#the-forecast").text(currentForecast);
  
  if (currentForecast == "Rain"){
   
    $("#weather-photo").attr("src","assets/umbrella.png")
    
  } else if (currentForecast == "Sunny"){
    $("#weather-photo").attr("src","assets/sun.png")
  } else {
    //??
    $("#weather-photo").attr("src","assets/cloud.png")  
  }
}

$.getJSON(url, grabMyData );

let currentTemperature= true;

if (currentTemperature >= 99 && currentTemperature <= 90){
    $("#Nirvana").show();
    $("#Beatles").hide();
    $("#RollingStones").hide();
    $("#ElvisPresley").hide();
    $("Eagles").hide();
    $("Freedie").hide();
}